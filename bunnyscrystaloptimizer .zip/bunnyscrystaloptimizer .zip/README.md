# WalksyCrystalOptimizer
+ Allows for faster crystal placement
+ Do NOT use my antiCrystalRefresh mod with this as it causes crystals to decrease TOO much
+ Love from snrios

![meowbah-meowbahh](https://github.com/Walksy/WalksyCrystalOptimizer/assets/69202220/00cf00a2-757c-471e-bad6-4ed8620c01e4)


<p align="left">
	<img width=331 src="github/Review12.png" /> 
	<img width=331 src="github/Review2.png" />
</p>



  
